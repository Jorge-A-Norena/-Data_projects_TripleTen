# SPRINT 5: STORYTELLING WITH DATA

In this project we have been tasked to work as a consultant using Tableau to review what is causing the high number of returned orders at the Superstore.

## TABLEAU PUBLIC WORKBOOK

(https://public.tableau.com/views/StorytellingwithDataProject_17165155078240/SuperstoreStoryArc?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link)

## PROJECT OVERVIEW

As a culmination of our Storytelling with Data Sprint at TripleTen, we were tasked to work on a project to review the superstore's High number of returned orders. We were given an .xls file with 3 sheets and information ranging from Order ID, Customer Name, Region, Product Name, etc.

[Link to .xls file](https://practicum-content.s3.us-west-1.amazonaws.com/data-eng/remodeled/dvwt/Superstore.xls?etag=4616d537c163874941cf5fc3c9002fa8)

## TOOLS USED

- Tableau Public
- Excel

## CONCLUSION AND PROPOSED NEXT STEPS

Conclusion
Our comprehensive store analysis has unveiled several critical insights. Firstly, while there is a weak positive correlation between sales and returns, the overall return rates are notably high across all product categories, with Office Supplies and Furniture exhibiting the highest rates. These return rates significantly surpass industry standards, especially in the Technology category. Furthermore, regional analysis reveals that the West Region, particularly states like Utah, California, and Oregon, has the highest return rates, whereas the Central Region has the lowest but also the lowest profit margins. Customer behavior analysis highlights individuals with exceptionally high return rates, notably Seth Vernon with a 93% return rate. Seasonal trends indicate peaks in returns post-holiday and during back-to-school periods, with the highest sales in March due to seasonal promotions.

Proposed Next Steps
- Investigate and enhance the quality of products in categories with high return rates, particularly Office Supplies and Furniture.
- Reassess and possibly tighten return policies to reduce the high return rates, especially in the West Region.
- Engage with customers who have high return rates to understand their issues and provide solutions or incentives to reduce returns.
- Offer personalized support and possibly loyalty rewards to customers with low return rates to encourage repeat purchases.
- Develop strategies to boost profitability in the Central Region, such as targeted marketing campaigns or promotions.
- Tailor promotional strategies to align with regional behaviors, focusing on reducing return rates in the West Region.
- Implement pre-season marketing campaigns to manage and balance sales peaks, particularly before January and the back-to-school season.
- Plan post-season strategies to handle higher returns efficiently, offering extended customer support and return processing capabilities.
- Regularly analyze monthly sales and return trends to adjust strategies promptly, ensuring agility in responding to changing consumer behaviors.

By implementing these steps, we aim to improve product quality, customer satisfaction, and regional performance, thereby driving profitability and reducing the overall return rates.

## CONTACT INFORMATION

- Jorge Norena 
  - Email: [jorgenorena1980@gmail.com](mailto:jorgenorena1980@gmail.com)
