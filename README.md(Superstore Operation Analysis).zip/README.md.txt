# SPRINT 4: DATA VISUALIZATION WITH TABLEAU

In this project we have been tasked to work as a consultant using Tableau to review the supersore's operations and increase its profitability to avoid bankruptcy.

## TABLEAU PUBLIC WORKBOOK

(https://public.tableau.com/views/TableauprojectSprint4/ProfitCentersLoss-makers?:language=en-US&:sid=&:display_count=n&:origin=viz_share_link)


## PROJECT OVERVIEW

As a culmination of our Data Visualization Sprint at TripleTen, we were tasked to work on a project to review the superstore's operations and increase its profitability to avoid bankruptcy. We were given an .xls file with 3 sheets and information ranging from Order ID, Customer Name, Region, Product Name, etc.

[Link to .xls file](https://practicum-content.s3.us-west-1.amazonaws.com/data-eng/remodeled/dvwt/Superstore.xls?etag=4616d537c163874941cf5fc3c9002fa8)

## TOOLS USED

- Tableau Public
- Excel

## FINDINGS AND CONCLUSION

In Part 1 dashboard, our visualizations show the top two profit-making sectors and the top two sectors causing the most losses. In Part 2, the visualization indicating the Return On Ad Spend (ROAS), focuses on the most effective combination of states and months for advertising. Lastly, Part 3 dashboard displays the top 15 returned products, the 10 customers with the highest return rates, and a comparison of average profit versus average return rate for each sub-category.

To boost sales, the superstore should concentrate efforts on promoting Office Supplies and Technology categories, especially items like copiers, phones, and accessories in the western US. Conversely, we recommend halting the sale of furniture and certain office supplies in the central region, and tables, bookcases, and general supplies across all regions. Additionally, discontinuing the sale of specific products like the "GBC DocuBind P400 Electric Binding System" and nine others from furniture and technology categories across all regions could be beneficial.

For advertising, targeting efforts could be worthwhile in October in Indiana, November in Vermont, and March in Washington.

Among returned products, there's a 100% return rate for five technology, three office supplies, and one furniture product. Furthermore, there are ten customers with an overall return rate of at least 86%. Notably, the Technology category, and particularly the Copiers subcategory, stands out as the only strong performer when comparing average profit against average return rate.

## CONTACT INFORMATION

- Jorge Norena 
  - Email: [jorgenorena1980@gmail.com](mailto:jorgenorena1980@gmail.com)
